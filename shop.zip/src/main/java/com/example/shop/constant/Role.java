package com.example.shop.constant;

public enum Role {
    USER, ADMIN
}
