package com.example.shop.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
