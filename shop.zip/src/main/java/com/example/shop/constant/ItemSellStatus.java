package com.example.shop.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
