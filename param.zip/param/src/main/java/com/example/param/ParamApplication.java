package com.example.param;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParamApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParamApplication.class, args);
	}

}
