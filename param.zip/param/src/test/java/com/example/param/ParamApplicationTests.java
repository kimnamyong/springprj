package com.example.param;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParamApplicationTests {

	@Test
	void contextLoads() {
	}

}
