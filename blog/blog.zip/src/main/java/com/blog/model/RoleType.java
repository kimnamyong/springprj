package com.blog.model;

public enum RoleType {
 USER,
 ADMIN
}
