package com.blog.test;

import lombok.Data;

@Data
public class MyData {
  private String msg;

}
