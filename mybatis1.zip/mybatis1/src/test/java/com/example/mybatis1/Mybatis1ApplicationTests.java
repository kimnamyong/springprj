package com.example.mybatis1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mybatis1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
