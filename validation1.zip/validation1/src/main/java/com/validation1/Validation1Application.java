package com.validation1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Validation1Application {

	public static void main(String[] args) {
		SpringApplication.run(Validation1Application.class, args);
	}

}
