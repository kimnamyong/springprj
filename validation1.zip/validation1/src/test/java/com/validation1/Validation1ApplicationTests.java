package com.validation1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Validation1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
