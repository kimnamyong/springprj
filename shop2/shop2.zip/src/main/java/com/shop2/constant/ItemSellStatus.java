package com.shop2.constant;

public enum ItemSellStatus {
 SELL, SOLD_OUT
}
