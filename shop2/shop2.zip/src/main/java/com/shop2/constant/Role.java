package com.shop2.constant;

public enum Role {
 USER,ADMIN
}
