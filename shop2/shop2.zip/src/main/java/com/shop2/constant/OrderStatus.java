package com.shop2.constant;

public enum OrderStatus {
 ORDER, CANCEL
}
