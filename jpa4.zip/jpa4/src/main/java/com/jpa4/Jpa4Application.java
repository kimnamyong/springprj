package com.jpa4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa4Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpa4Application.class, args);
	}

}
