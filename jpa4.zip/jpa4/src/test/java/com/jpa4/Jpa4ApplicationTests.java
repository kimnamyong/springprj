package com.jpa4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpa4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
