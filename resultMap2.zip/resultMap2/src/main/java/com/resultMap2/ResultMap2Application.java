package com.resultMap2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResultMap2Application {

	public static void main(String[] args) {
		SpringApplication.run(ResultMap2Application.class, args);
	}

}
