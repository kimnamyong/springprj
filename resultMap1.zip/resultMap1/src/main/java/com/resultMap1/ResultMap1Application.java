package com.resultMap1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResultMap1Application {

	public static void main(String[] args) {
		SpringApplication.run(ResultMap1Application.class, args);
	}

}
