package com.resultMap1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResultMap1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
