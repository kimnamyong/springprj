package com.test4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
